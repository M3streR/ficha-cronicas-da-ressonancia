/* Local, memory-only Portrait experiment. No character database or external service. */
const http = require('node:http');
const fs = require('node:fs/promises');
const path = require('node:path');
const {randomInt,randomUUID} = require('node:crypto');
const MAX_BODY = 4 * 1024 * 1024;
const MAX_SNAPSHOT_BODY = 32 * 1024 * 1024;
const files = new Map([
  ['/', ['control.html','text/html; charset=utf-8']],
  ...['control.html','overlay.html'].map(f=>['/'+f,[f,'text/html; charset=utf-8']]),
  ...['control.js','overlay.js'].map(f=>['/'+f,[f,'text/javascript; charset=utf-8']]),
  ...['control.css','overlay.css'].map(f=>['/'+f,[f,'text/css; charset=utf-8']]),
  ['/assets/portrait-demo.svg',['assets/portrait-demo.svg','image/svg+xml']],
  ['/assets/portrait-placeholder.svg',['../assets/portrait.svg','image/svg+xml']],
  ...['Cinzel.ttf','Spectral-Regular.ttf'].map(f=>['/assets/fonts/'+f,['assets/fonts/'+f,'font/ttf']])
]);
const initialState=()=>({name:'Lia Vesper',className:'Vanguarda',signature:'Luas de Éter',portraitImage:'/assets/portrait-demo.svg',imageX:50,imageY:30,imageZoom:100,pv:{current:25,max:40},pn:{current:9,max:14},ps:{current:20,max:24}});
class RequestError extends Error{constructor(status,message){super(message);this.status=status;}}
function integer(value,min,max,label){if(!Number.isInteger(value)||value<min||value>max)throw new RequestError(400,`${label}: informe um inteiro entre ${min} e ${max}.`);return value;}
function validatePatch(patch){
  if(!patch||typeof patch!=='object'||Array.isArray(patch))throw new RequestError(400,'Envie um objeto JSON.');
  const out={};for(const key of Object.keys(patch)){
    if(['name','className','signature'].includes(key)){const limit=key==='signature'?64:48;if(typeof patch[key]!=='string'||patch[key].trim().length>limit)throw new RequestError(400,`Texto inválido em ${key} (máximo ${limit} caracteres).`);out[key]=patch[key].trim();}
    else if(['imageX','imageY','imageZoom'].includes(key)){out[key]=integer(patch[key],key==='imageZoom'?100:0,key==='imageZoom'?200:100,'Enquadramento');}
    else if(['pv','pn','ps'].includes(key)){const r=patch[key];if(!r||typeof r!=='object'||Array.isArray(r)||Object.keys(r).some(k=>!['current','max'].includes(k)))throw new RequestError(400,'Recurso inválido.');out[key]={current:integer(r.current,0,9999,'Valor atual'),max:integer(r.max,0,9999,'Valor máximo')};}
    else if(key==='portraitImage'){
      const value=patch[key];if(value==='/assets/portrait-demo.svg'){out[key]=value;continue;}
      if(typeof value!=='string'||value.length>MAX_BODY-2048)throw new RequestError(400,'Use uma imagem PNG, JPEG ou WebP de até 2,5 MB.');
      const match=/^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/]+={0,2})$/.exec(value);
      if(!match)throw new RequestError(400,'Formato de imagem inválido: use PNG, JPEG ou WebP.');
      const bytes=Buffer.from(match[2],'base64');const valid=match[1]==='png'?bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])):match[1]==='jpeg'?bytes[0]===255&&bytes[1]===216&&bytes[2]===255:bytes.toString('ascii',0,4)==='RIFF'&&bytes.toString('ascii',8,12)==='WEBP';
      if(!valid)throw new RequestError(400,'O conteúdo da imagem não corresponde ao formato informado.');out[key]=value;
    }else throw new RequestError(400,'Campo desconhecido: '+key);
  }return out;
}
async function body(req,limit=MAX_BODY){if(!req.headers['content-type']?.startsWith('application/json'))throw new RequestError(415,'Use Content-Type: application/json.');let size=0;const chunks=[];for await(const chunk of req){size+=chunk.length;if(size>limit)throw new RequestError(413,'Imagem grande demais para a cópia local do Portrait. A ficha não foi alterada.');chunks.push(chunk);}try{return JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{throw new RequestError(400,'JSON inválido.');}}
function createPortraitServer({randomFace=()=>randomInt(1,21),initialPatch={},allowedPreviewOrigin='',allowedSiteOrigins=[]}={}){
  const allowedOrigins=[...new Set([allowedPreviewOrigin,...allowedSiteOrigins].filter(Boolean))];
  for(const origin of allowedOrigins){let value;try{value=new URL(origin);}catch{throw Error('Origem HTTPS de prévia inválida.');}if(value.protocol!=='https:'||value.origin!==origin||value.username||value.password||value.hostname.includes('*')||['localhost','127.0.0.1','[::1]'].includes(value.hostname))throw Error('Use uma origem HTTPS exata, sem caminho, para cada site autorizado.');}

  const characters=new Map(),rollIds=new Map(),instanceId=randomUUID();
  let state={...initialState(),...validatePatch(initialPatch)},revision=0,lastRoll=null;const clients=new Set();
  const send=(res,event,data)=>res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
  const broadcast=(event,data,characterId=null)=>{for(const res of clients){if(res.portraitCharacterId!==characterId)continue;if(res.writableLength>MAX_BODY){res.destroy();clients.delete(res);}else send(res,event,data);}};
  const server=http.createServer(async(req,res)=>{
    res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');
    res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; frame-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'self' http://127.0.0.1:* http://localhost:*"+(allowedOrigins.length?' '+allowedOrigins.join(' '):''));
    const json=(code,data)=>{res.writeHead(code,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(data));};
    try{
      const host=req.headers.host||'';if(!/^(127\.0\.0\.1|localhost)(:\d+)?$/.test(host))throw new RequestError(403,'Este protótipo aceita somente acesso local.');
      const url=new URL(req.url,'http://'+host);
      const characterRoute=/^\/api\/characters\/([A-Za-z0-9_-]{1,128})(\/rolls)?$/.exec(url.pathname);
      const localOrigin=req.headers.origin&&/^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?$/.test(req.headers.origin);
      const previewOrigin=allowedOrigins.includes(req.headers.origin);
      const allowPanel=(localOrigin||previewOrigin)&&(characterRoute||url.pathname==='/api/health');
      if(allowPanel){res.setHeader('Access-Control-Allow-Origin',req.headers.origin);res.setHeader('Vary','Origin');res.setHeader('Access-Control-Allow-Methods','GET, PUT, POST, OPTIONS');res.setHeader('Access-Control-Allow-Headers','Content-Type');}
      if(req.headers.origin&&req.headers.origin!==url.origin&&!allowPanel)throw new RequestError(403,'Origem não autorizada. Abra o painel no mesmo endereço do overlay.');
      if(req.method==='OPTIONS'&&allowPanel){if(req.headers['access-control-request-private-network']==='true')res.setHeader('Access-Control-Allow-Private-Network','true');res.writeHead(204);return res.end();}
      if(characterRoute){
        const id=characterRoute[1];
        if(characterRoute[2]){
          if(req.method!=='POST')throw new RequestError(405,'Método não permitido.');
          const record=await body(req);const result=record?.result;
          if(!record||record.characterId!==id||typeof record.id!=='string'||record.id.length>128||!result||typeof result.expression!=='string'||result.expression.length>256||!Number.isFinite(result.total)||!Array.isArray(result.rolls)||result.rolls.length>1000||result.rolls.some(v=>!Number.isFinite(v))||(result.modifier!==undefined&&!Number.isFinite(result.modifier)))throw new RequestError(400,'Evento de rolagem inválido.');
          if(!characters.has(id))throw new RequestError(404,'Abra a ficha deste personagem para carregar seu Portrait.');
          let seen=rollIds.get(id);if(!seen){seen=new Set();rollIds.set(id,seen);}if(seen.has(record.id))return json(200,{duplicate:true,id:record.id});seen.add(record.id);if(seen.size>1000)seen.delete(seen.values().next().value);
          const sides=result.faces??result.sides,natural=result.natural??(sides===20&&result.rolls.length===1?result.rolls[0]:null);
          const packet={id:record.id,characterId:id,label:record.label||record.name||(record.source==='quick-dice'?'Rolador rápido':record.source==='online-combat'?'Combate':'Rolagem'),expression:result.expression,rolls:result.rolls,modifier:result.modifier,total:result.total,dieSides:sides,natural,resolution:record.resolution,source:record.source,category:record.category,createdAt:record.createdAt,result};broadcast('roll',packet,id);return json(200,{id:packet.id});
        }

        if(req.method==='GET'){const value=characters.get(id);if(!value)throw new RequestError(404,'Abra a ficha deste personagem para carregar os dados do Portrait.');return json(200,{characterId:id,...value});}
        if(req.method==='PUT'){
          const input=await body(req,MAX_SNAPSHOT_BODY);if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(k=>!['name','portraitImage','pv','pn','ps','sync'].includes(k)))throw new RequestError(400,'Snapshot de Portrait inválido.');
          if(typeof input.name!=='string'||input.name.length>256)throw new RequestError(400,'Nome do personagem inválido.');
          const resources=validatePatch({pv:input.pv,pn:input.pn,ps:input.ps});
          let image=input.portraitImage;
          if(image!=='/assets/portrait-placeholder.svg'&&(typeof image!=='string'||image.length>MAX_SNAPSHOT_BODY-2048||!/^data:image\/[a-z0-9.+-]+;base64,[A-Za-z0-9+/]+={0,2}$/i.test(image)))throw new RequestError(400,'Foto inválida para a prévia. A imagem da ficha não foi alterada.');
          if(!characters.has(id)&&characters.size>=128)throw new RequestError(503,'Limite de prévias locais atingido. Reinicie o servidor para liberar as cópias temporárias.');
          const sync=input.sync,previous=characters.get(id)?.sync;
          if(sync!==undefined){if(!sync||typeof sync.publisher!=='string'||sync.publisher.length>128||!Number.isFinite(sync.epoch)||!Number.isSafeInteger(sync.sequence)||sync.sequence<1)throw new RequestError(400,'Sequência de publicação inválida.');if(previous&&(sync.epoch<previous.epoch||(sync.epoch===previous.epoch&&(sync.publisher!==previous.publisher||sync.sequence<=previous.sequence))))return json(200,{stale:true,revision:characters.get(id).revision});}
          else if(previous)return json(200,{stale:true,revision:characters.get(id).revision});
          const value={sync,state:{...initialState(),...resources,name:input.name,portraitImage:image},revision:(characters.get(id)?.revision||0)+1,lastRoll:null};characters.set(id,value);broadcast('state',value,id);return json(200,{characterId:id,...value});
        }throw new RequestError(405,'Método não permitido.');
      }
      if(req.method==='GET'&&url.pathname==='/api/events'){
        const characterId=url.searchParams.has('character')?url.searchParams.get('character'):null;
        if(characterId!==null&&!/^[A-Za-z0-9_-]{1,128}$/.test(characterId))throw new RequestError(400,'Identificador de personagem inválido.');
        if(clients.size>=16)throw new RequestError(503,'Limite de conexões experimentais atingido.');
        res.writeHead(200,{'Content-Type':'text/event-stream; charset=utf-8','Connection':'keep-alive','X-Accel-Buffering':'no'});res.write('retry: 1500\n\n');clients.add(res);res.portraitCharacterId=characterId;if(characterId===null)send(res,'snapshot',{state,revision,lastRoll});else if(characters.has(characterId))send(res,'snapshot',characters.get(characterId));else send(res,'unavailable',{message:'Abra a ficha deste personagem para carregar os dados do Portrait.'});req.on('close',()=>clients.delete(res));return;
      }
      if(req.method==='GET'&&url.pathname==='/api/state')return json(200,{state,revision,lastRoll});
      if(req.method==='GET'&&url.pathname==='/api/health')return json(200,{localOnly:true,storage:'memory',clients:clients.size,revision,instanceId});
      if(req.method==='PATCH'&&url.pathname==='/api/state'){
        const patch=validatePatch(await body(req));state={...state,...patch};revision++;broadcast('state',{state,revision});return json(200,{state,revision});
      }
      if(req.method==='POST'&&url.pathname==='/api/roll'){
        const input=await body(req);if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(k=>!['modifier','label'].includes(k)))throw new RequestError(400,'Informe o modificador e, opcionalmente, o nome do teste.');
        if(input.label!==undefined&&(typeof input.label!=='string'||input.label.trim().length>32))throw new RequestError(400,'Nome da rolagem inválido (máximo 32 caracteres).');
        const modifier=integer(input.modifier,-99,99,'Modificador'),natural=integer(randomFace(),1,20,'D20');
        lastRoll={id:randomUUID(),label:input.label?.trim()||'TESTE D20',dieSides:20,expression:`1d20 ${modifier<0?'−':'+'} ${Math.abs(modifier)}`,natural,modifier,total:natural+modifier,at:new Date().toISOString()};broadcast('roll',lastRoll);return json(200,{roll:lastRoll});
      }
      if(req.method!=='GET'&&req.method!=='HEAD')throw new RequestError(405,'Método não permitido.');
      const file=files.get(url.pathname);if(!file)throw new RequestError(404,'Página não encontrada.');
      const content=await fs.readFile(path.join(__dirname,file[0]));res.writeHead(200,{'Content-Type':file[1]});res.end(req.method==='HEAD'?undefined:content);
    }catch(error){if(!res.headersSent)json(error.status||500,{error:error.status?error.message:'Falha local ao processar o pedido.'});else res.end();}
  });
  const heartbeat=setInterval(()=>{for(const res of clients)res.write(': heartbeat\n\n');},15000);heartbeat.unref();
  server.on('close',()=>clearInterval(heartbeat));
  server.disconnectPortraitClients=()=>{for(const res of clients)res.end();clients.clear();};
  server.closePortrait=()=>{server.disconnectPortraitClients();server.close();server.closeAllConnections();};return server;
}
if(require.main===module){const port=Number(process.env.PORTRAIT_PORT||8771);if(!Number.isInteger(port)||port<1024||port>65535)throw Error('Porta inválida. Use 1024–65535.');const server=createPortraitServer({allowedPreviewOrigin:process.env.PORTRAIT_PREVIEW_ORIGIN||'',allowedSiteOrigins:(process.env.PORTRAIT_ALLOWED_ORIGINS||'').split(',').map(v=>v.trim()).filter(Boolean)});server.on('error',e=>{console.error(e.code==='EADDRINUSE'?`A porta ${port} já está em uso. Escolha outra com PORTRAIT_PORT.`:e.message);process.exitCode=1;});server.listen(port,'127.0.0.1',()=>console.log(`Portrait Ressonante · somente local\nPainel: http://127.0.0.1:${port}/\nOBS: http://127.0.0.1:${port}/overlay.html\nFonte de Navegador HD: 640 × 1088 · reduzir para 25% na cena (card 160 × 160) · dados fictícios em memória`));for(const signal of ['SIGINT','SIGTERM'])process.once(signal,()=>server.closePortrait());}
module.exports={createPortraitServer,validatePatch,initialState};
