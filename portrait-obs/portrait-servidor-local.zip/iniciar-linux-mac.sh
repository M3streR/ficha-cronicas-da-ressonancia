#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/portrait-obs"
export PORTRAIT_ALLOWED_ORIGINS="https://m3strer.github.io,https://ficha-cronicas-da-ressonancia.vercel.app,https://ficha-cronicas-da-ressonancia-felipegamercps-2752.vercel.app,https://ficha-cronicas-da-ressonancia-git-main-felipegamercps-2752.vercel.app"
exec node server.cjs
