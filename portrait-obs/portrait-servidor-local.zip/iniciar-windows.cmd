@echo off
cd /d "%~dp0portrait-obs"
where node >nul 2>nul
if errorlevel 1 (echo Instale Node.js 20 ou superior em https://nodejs.org/ & pause & exit /b 1)
set "PORTRAIT_ALLOWED_ORIGINS=https://m3strer.github.io,https://ficha-cronicas-da-ressonancia.vercel.app,https://ficha-cronicas-da-ressonancia-felipegamercps-2752.vercel.app,https://ficha-cronicas-da-ressonancia-git-main-felipegamercps-2752.vercel.app"
node server.cjs
pause
